clc;clear;
a=imread('house.jpg');
b=rgb2gray(a);
[m,n]=size(b);
picturename={};
fid=fopen('.\name.txt','w');
for num=1:15
    for i=1:m
        for j=1:n
            b(i,j)=b(i,j)-0.6*num;
            
        end
    end
    if num<10
        picname=['0',num2str(num),'.bmp'];
    else
        picname=[num2str(num),'.bmp']
    end
    imwrite(b,picname);
    picturename{num}=['   /',num2str(num),' = "',picname,'"'];%����item
    fprintf(fid,'%s\r\n',picturename{num});%��item�����txt�ļ�
end
fclose(fid);